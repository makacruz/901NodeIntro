let firstName = 'john';
let lastName = 'Smith';

function Person(fname, lname) {
    this.fname = fname;
    this.lname = lname;
    this.getFullName = function() {
        return `${this.fname} ${this.lname}`
    }
}

let person1 = new Person(firstName, lastName);
person1.fname = 'xxxxx';
console.log(person1.getFullName());

const tempsArray =
[
    { day: 'Monday', high: 80, low: 68},
    { day: 'Tues', high: 89, low: 77},
    { day: 'Wed', high: 69, low: 65},
    { day: 'Thurs', high: 102, low: 90},
    { day: 'Fri', high: 83, low: 78}
];

let lowestDay = tempsArray[0];
let highestDay = tempsArray[0];

tempsArray.forEach(element => {
    if (lowestDay.low > element.low) {
        lowestDay = element;
    }

    if (highestDay.high < element.high) {
        highestDay = element;
    }
});

console.log (`The lowest temperature this week was on ${lowestDay.day} and it was ${lowestDay.low}`);


console.log (`The highest temperature this week was on ${highestDay.day} and it was ${highestDay.high}`);

/*---------------------------*/
var moment = require('moment');
var moment_tz = require('moment-timezone');
console.log(moment().format('MM-DD-YYYY'));

console.log(
moment("20110101","YYYYMMDD").fromNow()
);


let now = moment_tz();

let message =
    moment_tz.tz('America/New_York').format('ha z') + ' is ' +
    moment_tz.tz('America/Los_Angeles').format('ha z');
    
    console.log(message);