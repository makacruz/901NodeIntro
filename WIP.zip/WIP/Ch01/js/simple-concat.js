let firstName = 'Lamar';
let lastName = 'Jackson';

function Person(firstName, lastName) {
    this.firstName = firstName;
    this.lastName = lastName;
    this.getFullName = function () {
        return `${this.fname} ${this.lname}`

    }
}

let person1 = new Person(firstName, lastName);
person1.fname = 'Thomas';
console.log('Hello');
console.log(person1.getFullName());













































