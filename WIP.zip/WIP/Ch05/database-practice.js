const Promise = require("bluebird");
const knex = require("knex");
let db = knex(require("./knexfile"));

Promise.try(() => {
    return db.schema.createTable("customer", (table) => {
        table.increments("id").primary();
        table.text("firstname");
        table.text("lastname");
        table.text("email");
    });
}).then(() => {



    return db("customer").insert([
        {firstname: "Peter",lastname: "Pan",email: "peterpan@email.com"}, 
        {firstname: "Jane",lastname: "Lee",email: "janelee@email.com"},
        {firstname: "Thomas",lastname: "Pane",email: "thomaspane@email.com"},
        {firstname: "Lamar",lastname: "Jackson",email: "lamarjackson@email.com"},
    ]).then (() => {
        console.log("Done!");
    }).finally(() => {
        db.destroy();
    });
});