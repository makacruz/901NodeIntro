module.exports = class Calculator {
    
    add(a,b) {
        return a+b;
    }
}