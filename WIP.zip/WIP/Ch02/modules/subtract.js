module.exports = function subtract(a,b) {
    return b-a;
}